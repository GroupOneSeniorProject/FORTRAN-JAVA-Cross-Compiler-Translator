import java.util.ArrayList;

/**
 * Created by Wes Groover on 9/23/2017.
 */
public class VariableBuilder {
    
    VariableBuilder(){}

    void findTargetList(ArrayList<String> integerVariables, ArrayList<String> doubleVariables, ArrayList<String> stringVariables,
                        ArrayList<String> booleanVariables, ArrayList<String> complexVariables, ArrayList<String> tokens){

        if(tokens.get(0).equalsIgnoreCase("integer"))
            build(integerVariables, tokens);
        else if(tokens.get(0).equalsIgnoreCase("real"))
            build(doubleVariables, tokens);
        else if(tokens.get(0).equalsIgnoreCase("logical"))
            build(booleanVariables, tokens);
        else if(tokens.get(0).equalsIgnoreCase("complex"))
            build(complexVariables, tokens);
        else
            build(stringVariables, tokens);

    }
    
    void build(ArrayList<String> targetList, ArrayList<String> tokens){
        for(int i = 2; i < tokens.size(); ++i){
            if(tokens.get(i).charAt(tokens.get(i).length() - 1) == ','){
                int endIndex = tokens.get(i).length() - 1;
                String thisSubstring = tokens.get(i).substring(0, endIndex);
                targetList.add(thisSubstring);
            }
            else
                targetList.add(tokens.get(i));
        }
    }
}
