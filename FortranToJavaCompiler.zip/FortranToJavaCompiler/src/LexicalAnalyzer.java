import java.util.*;
import java.io.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LexicalAnalyzer {

    String fileName;
    LinkedList<String> keyWords = new LinkedList<String>();
    LinkedList<String> Fortran = new LinkedList<String>();
    LinkedList<String> JavaCode = new LinkedList<>();
    ArrayList<String> integerVariables = new ArrayList<>();
    ArrayList<String> doubleVariables = new ArrayList<>();
    ArrayList<String> stringVariables = new ArrayList<>();
    ArrayList<String> booleanVariables = new ArrayList<>();
    ArrayList<String> complexVariables = new ArrayList<>();

    public LexicalAnalyzer() {
        //this is an array of all keywords through Fortran 95
        final String[] keywordsArray = {"real", "integer", "complex", "logical", "character", "assign", "backspace",
                "block data", "call", "close", "common", "continue", "data", "dimension", "do", "else", "else if", "end",
                "endfile", "endif", "entry", "equivalence", "external", "format", "function", "goto", "if",
                "implicit", "inquire", "intrinsic", "open", "parameter", "pause", "print", "program", "read",
                "return", "rewind", "rewrite", "save", "stop", "subroutine", "then", "write", "allocatable",
                "allocate", "case", "contains", "cycle", "deallocate", "elsewhere", "exit", "include",
                "interface", "intent", "module", "namelist", "nullify", "only", "operator", "optional",
                "pointer", "private", "procedure", "public", "recursive", "result", "select", "sequence",
                "target", "use", "while", "where", "elemental", "forall", "pure"};

        //Use a loop to load all keywords into the list at once.
        for (int i = 0; i < keywordsArray.length; i++) {

            keyWords.add(keywordsArray[i]);

        }
        openF95("FirstDeliverable.f95"); //For IntelliJ, file must be in project root folder
        check();
    }


    //Open .f95 file and fill Fortran list
    public void openF95(String fileName) {
        try {
            File file = new File(fileName);
            Scanner scanner = new Scanner(file);
            while (scanner.hasNext()) {
                Fortran.add(scanner.nextLine());
            }

            scanner.close();
            //Fortran.removeAll(Arrays.asList("", null));
        } catch (Exception fileIO) {
            System.out.println(fileIO);
        }
    }


    //This is where we pass to appropriate object
    public void check() {

        JavaCode.add("import java.util.*;");
        for (int i = 0; i < Fortran.size(); i++) {

            String[] thisLine = Fortran.get(i).split(" ");
            ArrayList<String> tokens = new ArrayList<>();
            boolean containsKeyword = false;

            for (String s : thisLine) {
                if (!s.isEmpty()) {
                    tokens.add(s);
                }
            }
            if(!tokens.isEmpty()) {
                Pattern charPattern = Pattern.compile("character.*");
                Matcher matcher = charPattern.matcher(tokens.get(0));
                if (matcher.matches())
                    tokens.set(0, "character");
            }

            if (!tokens.isEmpty() && keyWords.contains(tokens.get(0))) {



                if (tokens.size() > 0 && keyWords.contains(tokens.get(0))) {
                    if (tokens.get(0).equalsIgnoreCase("integer") ||
                            tokens.get(0).contains("character") ||
                            tokens.get(0).equalsIgnoreCase("logical") ||
                            tokens.get(0).equalsIgnoreCase("real") ||
                            tokens.get(0).equalsIgnoreCase("complex")) {
                        VariableBuilder variableBuilder = new VariableBuilder();
                        variableBuilder.findTargetList(integerVariables, doubleVariables,
                                stringVariables, booleanVariables, complexVariables, tokens);
                    }

                    //Just a check, this is the if statement where we pass to other class

                    if (tokens.get(0).equalsIgnoreCase("program")) {
                        functions fun = new functions();
                        String y = fun.startprogram(tokens.get(1));
                        fileName = tokens.get(1);
                        JavaCode.add(y);
                    } else if (tokens.get(0).equalsIgnoreCase("implicit")) {
                        continue;
                    } else if (tokens.get(0).equalsIgnoreCase("print")) {
                        IOHandler ioHandler = new IOHandler();
                        String y = ioHandler.printFunction(tokens);
                        JavaCode.add(y);
                    } else if (tokens.get(0).equalsIgnoreCase("read")) {
                        IOHandler ioHandler = new IOHandler();
                        ioHandler.readFunction(integerVariables, doubleVariables, stringVariables, booleanVariables, complexVariables, tokens, JavaCode);
                    } else if (tokens.get(0).equalsIgnoreCase("end")) {
                        JavaCode.add("}\n");
                    }
                }
            } else {
                String newJavaLine = "";
                for (String s : thisLine) {
                    if (s.equals(""))
                        continue;
                    else {
                        newJavaLine += s + " ";
                    }
                }
                if (newJavaLine.length() > 0) {
                    newJavaLine += ";";
                } else {
                    newJavaLine = "\n";
                }
                JavaCode.add(newJavaLine);
            }
        }

        try {
            PrintWriter printWriter = new PrintWriter(fileName + ".java");
            for (String s : JavaCode) {
                printWriter.println(s);
            }
            printWriter.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
}
