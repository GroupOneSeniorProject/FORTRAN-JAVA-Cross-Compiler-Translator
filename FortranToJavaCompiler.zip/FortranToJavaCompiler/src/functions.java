public class functions
{
    public functions()
    {

    }
    String startprogram(String s){
        String thisProgram = "public class " + s + "{\n public static void main(String[] args){\n";
        return thisProgram;
    }
}