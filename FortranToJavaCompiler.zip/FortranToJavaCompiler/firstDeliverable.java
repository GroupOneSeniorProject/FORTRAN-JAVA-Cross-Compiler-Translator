import java.util.*;
public class firstDeliverable{
 public static void main(String[] args){









System.out.println("Enter two numbers to be added together:" );


Scanner scanner = new Scanner(System.in);
a = scanner.nextInt();
scanner.close()


Scanner scanner = new Scanner(System.in);
b = scanner.nextInt();
scanner.close()


c = a + b ;


System.out.println("The result is " + c );


System.out.println("Enter a word of six letters or less" );


Scanner scanner = new Scanner(System.in);
string1 = scanner.nextLine();
scanner.close()


System.out.println("Enter a second word of six letters or less" );


Scanner scanner = new Scanner(System.in);
string2 = scanner.nextLine();
scanner.close()


bool = string1 == string2 ;




System.out.println("The words entered are identical" );




System.out.println("The words entered are different" );


}



}

