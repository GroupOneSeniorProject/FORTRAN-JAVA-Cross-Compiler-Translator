import java.util.ArrayList;

public class indentManager {
    String[] indents = {"", "\t", "\t\t", "\t\t\t", "\t\t\t\t", "\t\t\t\t\t"};
    ArrayList<Integer> lineNumbers;
    int currentIndentLevel;
    indentManager(){
        this.lineNumbers = new ArrayList<>();
        this.currentIndentLevel = 0;

    }
    void indent()
    {
        currentIndentLevel++;
    }
    void deindent()
    {
        currentIndentLevel--;
    }
    String returnLineIndent(int line)
    {
        return indents[lineNumbers.get(line)];
    }
    void logIndentLevel()
    {
        lineNumbers.add(currentIndentLevel);
    }
}