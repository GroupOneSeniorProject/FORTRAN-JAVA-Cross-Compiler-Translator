import java.util.*;

public class thirdDeliverable
{
	public static void main(String[] args)
	{
		Scanner scanner = new Scanner(System.in);

		int[] xVar = new int[5];
		
		
		int byTwo = 0;
		intWrapper byOne = new intWrapper();
		intWrapper yVar = new intWrapper();
		
		int i = 0;
		
		byOne.setValue(10);
		System.out.println("byOne.getValue() equals " + byOne.getValue() );
		incrementOne(byOne) ;
		System.out.println("byOne.getValue() equals " + byOne.getValue() );
		byTwo=10;
		System.out.println("byTwo equals " + byTwo );
		byTwo=incrementTwo(byTwo) ;
		System.out.println("byTwo equals " + byTwo );
		xVar[1-1]=1;
		xVar[2-1]=2;
		xVar[3-1]=3;
		xVar[4-1]=4;
		xVar[5-1]=5;
		yVar.setValue(5);
		i=1;
		while(i<=5){
			System.out.println(xVar[i-1] );
			i=i+1;
		}
		
		scalarmult(xVar, yVar) ;
		
		i=1;
		while(i<=5){
			System.out.println(xVar[i-1] );
			i=i+1;
		}
		
	}
	
	static void scalarmult(int [] xVar, intWrapper yVar){
		
	for(int i = 0; i < xVar.length; i++)
	{	xVar[i] = xVar[i]*yVar.getValue();
	}
	}
	
	static void incrementOne(intWrapper byOne){
		
		byOne.setValue(byOne.getValue()+1);
	}
	
	static int incrementTwo(int byTwo){
	
	int returnVariable;
	
	returnVariable=byTwo+2;
	return returnVariable;
}

}
