import java.lang.reflect.Array;
import java.util.LinkedList;
import java.util.StringJoiner;
import java.util.*;

public class AssignStatement {
    public AssignStatement() {

    }
    //building integer initialization and declaration
    public String integer(String[] s, int index, ArrayList<String> integer, ArrayList<String> globals) {
    	
        StringBuilder build = new StringBuilder();
        build.ensureCapacity(100);
        System.out.println("Hello");
        //globals.add("a");
        //globals.add("b");
        // build.append("int ");
        for (int i = index; i < s.length; i++) {
            if (!(globals.contains(s[i]) || s[i].equalsIgnoreCase("::") || s[i].equalsIgnoreCase("integer") ||
                    s[i].equalsIgnoreCase(",") || s[i].equalsIgnoreCase("=")
                    || s[i].equalsIgnoreCase("0"))) {
                build.append("int "+s[i].replace(",","") + " = 0;\n");
                integer.add(s[i].replace(",",""));
            }
        }
        for (int i = 0; i < globals.size(); i++)
        {
        	for (int j = 0; j < s.length; j++)
        	{
        		if (s[j].contains(globals.get(i)))
        		{
        			build.append("intWrapper " + globals.get(i) + " = new intWrapper();\n");
        			int temp = build.indexOf("int " +globals.get(i)+ " = 0;");
        			build.replace(temp, temp+j, "");
        		}
        	}
        }
        //build.append(";");


        return build.toString();
    }
    //building double initialization and declaration
    public String real(String[] s, int index,  ArrayList<String> real, ArrayList<String> globals) {
        StringBuilder build = new StringBuilder();
        build.ensureCapacity(100);
        //build.append("double ");
        for (int i = index; i < s.length; i++) {
            if (!(s[i].equalsIgnoreCase("::") || s[i].equalsIgnoreCase("real") ||
            		s[i].equalsIgnoreCase(",") || s[i].equalsIgnoreCase("=")
            		|| s[i].equalsIgnoreCase("0"))) {
                build.append("double " +s[i].replaceAll(",", "") + " = 0;\n" );
                real.add(s[i].replace(",",""));
            }
        }
        for (int i = 0; i < globals.size(); i++)
        {
        	for (int j = 0; j < s.length; j++)
        	{
        		if (s[j].contains(globals.get(i)))
        		{
        			build.append("doubleWrapper " + globals.get(i) + " = new doubleWrapper();\n");
        			int temp = build.indexOf("double " +globals.get(i)+ " = 0;");
        			build.replace(temp, temp+j, "");
        		}
        	}
        }
        //build.append(";");

        return build.toString();
    }
    //building boolean initilazation and declaration
    public String bool(String[] s, int index,  ArrayList<String> logical, ArrayList<String> globals) {
        StringBuilder build = new StringBuilder();
        build.ensureCapacity(100);
        build.append("boolean ");
        for (int i = index; i < s.length; i++) {
            if (!(s[i].equalsIgnoreCase("::") || s[i].equalsIgnoreCase("logical"))) {
                build.append(s[i] + " ");

                logical.add(s[i].replace(",",""));
            }
            
        }
        for (int i = 0; i < globals.size(); i++)
        {
        	for (int j = 0; j < s.length; j++)
        	{
        		if (s[j].contains(globals.get(i)))
        		{
        			build.append("booleanWrapper " + globals.get(i) + " = new booleanWrapper()");
        			int temp = build.indexOf("bool " +globals.get(i));
        			build.replace(temp, temp+j, "");
        		}
        	}
        }
        build.append(";");



        return build.toString();
    }
    //string init and declare
    public String character(String[] s, int index,  ArrayList<String> character, ArrayList<String> globals) {
        StringBuilder build = new StringBuilder();
        
        build.ensureCapacity(100);
        build.append("String ");
        int i = index;
        while (!s[i].equalsIgnoreCase("::"))
        {
            i++;
        }
        for (; i < s.length; i++) {
            {
                if (!(s[i].equalsIgnoreCase("::") || s[i].equalsIgnoreCase("character"))) {
                    build.append(s[i] + " ");
                    character.add(s[i].replace(",",""));

                }
            }
        }
        for (int l = 0; l < globals.size(); l++)
        {
        	for (int j = 0; j < s.length; j++)
        	{
        		if (s[j].contains(globals.get(l)))
        		{
        			build.append("booleanWrapper " + globals.get(l) + " = new booleanWrapper()");
        			int temp = build.indexOf("String " +globals.get(l));
        			build.replace(temp, temp+j, "");
        		}
        	}
        }
        build.append(";");
        return build.toString();
    }
    
      public String intArray(String[] s, int index,  ArrayList<String> character)
  {
    StringBuilder builder = new StringBuilder();

    builder.ensureCapacity(100);
    String arrLen = "";
    for(int i = 0; i < s.length; i++)
    {
      if(s[i].equalsIgnoreCase("integer,"))
      {
        builder.append("int[]");
      }
      if(s[i].contains("dimension"))
      {
        int first = s[i].indexOf('(');
        int second = s[i].indexOf(')');
        arrLen = s[i].substring(first + 1, second);
        //builder.append("[" + arrLen + "]");
      }
      if (!s[i].equalsIgnoreCase(" ") && !s[i].contains("dimension") && !s[i].equalsIgnoreCase("::") &&
              !s[i].contains("integer"))
      {

        builder.append(" " + s[i].replaceAll(",", ""));

      }

    }

    builder.append(" = new int[" + arrLen + "];");

    return builder.toString();

  }


}
